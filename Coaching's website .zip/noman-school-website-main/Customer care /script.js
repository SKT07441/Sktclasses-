// Get references to elements
const messages = document.getElementById('messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Knowledge base for chatbot
const knowledgeBase = {
    "hello": "Hi! Welcome to SKT Classes. How can I assist you today?",
    "location": "SKT Classes is located at coordinates: 27.3177978, 79.8272838.",
    "courses": "We offer courses in Maths, English, Hindi, Reasoning, and General Science for 7th to 12th grades.",
    "timings": "Our classes run from 8:00 AM to 6:00 PM, Monday to Saturday.",
    "dhruv sir": "Dhruv Sir teaches Reasoning and General Science with expertise.",
    "admission process": "To join SKT Classes, visit our center or call us at 123-456-7890. Online registration is also available.",
    "facilities": "We provide modern classrooms, animated lessons, and personal mentorship programs.",
    "fees": "Our fee structure is competitive and varies by course. Visit the center or contact us for details."
};

// Function to handle user messages
sendButton.addEventListener('click', () => {
    const userMessage = userInput.value.trim().toLowerCase();
    if (userMessage) {
        addMessage("You", userMessage);
        userInput.value = ""; // Clear input

        // Generate bot response
        setTimeout(() => {
            const botResponse = knowledgeBase[userMessage] || "Sorry, I don't have an answer for that. Please ask about our courses, timings, or facilities.";
            addMessage("SKT Bot", botResponse);
        }, 500);
    }
});

// Add message to chat window
function addMessage(sender, text) {
    const messageElement = document.createElement('div');
    messageElement.innerHTML = `<strong>${sender}:</strong> ${text}`;
    messages.appendChild(messageElement);
    messages.scrollTop = messages.scrollHeight; // Scroll to the latest message
}