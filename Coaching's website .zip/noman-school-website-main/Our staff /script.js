// Optional: Add interactivity to the buttons or trigger events
document.querySelectorAll('.action-btn').forEach(button => {
    button.addEventListener('click', (event) => {
        event.stopPropagation();
        alert("More information will be added soon!");
    });
});
